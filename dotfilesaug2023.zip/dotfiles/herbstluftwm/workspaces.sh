#!/usr/bin/env bash

pattern="$1"
workspaces=""

focused="$(wmctrl -d | awk '/\*/ {print $1}')"

focus_colour="#000000"
#activ_colour="#d6bad0"
activ_colour="#b39bae"
empty_colour="#d1d1d1"

function get_workspace_names {
  wmctrl -d \
    | awk '$9 ~ "^" { print $1 " " $2 " " $9 }' \
    | grep -v NSP
}

win=0

while read -r index active name; do
  name="${name#*_} "

  if [ "$index" == "$focused" ]; then
    workspaces+="%{F$focus_colour}%{A:herbstclient use_index $win:}$name%{A}%{F-}"
let "win++"
  elif wmctrl -l | grep --regexp '.*\s\+'"$index"'\s\+.*' >/dev/null; then
    workspaces+="%{F$activ_colour}%{A:herbstclient use_index $win:}$name%{A}%{F-}"
let "win++"
  else
    workspaces+="%{F$empty_colour}%{A:herbstclient use_index $win:}$name%{A}%{F-}"
let "win++"
  fi


done < <(get_workspace_names)

echo "%{c}"+"${workspaces}"



